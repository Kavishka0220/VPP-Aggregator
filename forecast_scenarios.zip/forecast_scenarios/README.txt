Scenario Forecast Pack (96 steps = 24h at 15-min)

Each scenario has:
- load_<scenario>.csv
- solar_<scenario>.csv

Scenarios:
1 solar_unavailable_day: solar set to 0 all day
2 cloudy_reduced_solar: solar reduced with variability
3 solar_shifted_late: solar delayed (morning clouds)
4 load_higher_day: all loads scaled up
5 daytime_peak_load_day: extra midday bump
6 evening_peak_load_day: extra evening bump
7 weekend_low_load: all loads scaled down
8 heatwave_day: higher daytime load + reduced solar
9 intermittent_solar_dropouts: random solar dropouts
10 night_blackout_window: load dip 00:00-02:00